extends AnimationPlayer
func _ready() -> void:
	$".".play("sol_para_lua")
	$".".play("luzes")
	$"../fuguera".play("fugueira")

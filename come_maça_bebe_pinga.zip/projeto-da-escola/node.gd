extends Node

func _ready() -> void:
	$"../animacoes".play("sol_para_lua")
	$"../fuguera".play("fugueira")
	$"../Animacoes".play("luzes")
